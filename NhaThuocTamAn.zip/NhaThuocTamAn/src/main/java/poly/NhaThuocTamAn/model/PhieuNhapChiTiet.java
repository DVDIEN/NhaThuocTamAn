package poly.NhaThuocTamAn.model;

public class PhieuNhapChiTiet {

}
