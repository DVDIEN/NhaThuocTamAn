package poly.NhaThuocTamAn.repository;

public class LichSuNhapXuatRepository {

}
