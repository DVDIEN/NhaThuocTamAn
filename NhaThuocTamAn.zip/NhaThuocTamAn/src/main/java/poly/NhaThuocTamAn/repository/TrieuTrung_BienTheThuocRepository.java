package poly.NhaThuocTamAn.repository;

public class TrieuTrung_BienTheThuocRepository {

}
