package poly.NhaThuocTamAn.repository;

public class ThanhToanRepository {

}
