package poly.NhaThuocTamAn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NhaThuocTamAnApplication {

	public static void main(String[] args) {
		SpringApplication.run(NhaThuocTamAnApplication.class, args);
	}

}
